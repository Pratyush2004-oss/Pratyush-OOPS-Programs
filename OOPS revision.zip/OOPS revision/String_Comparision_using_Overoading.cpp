#include <iostream>
using namespace std;

class StringCom{
    string a;
    
};
int main() {

    return 0;
}